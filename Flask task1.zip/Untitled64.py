#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from flask import Flask, request

# Step 1 - Create a Flask instance
app = Flask(__name__)

# Step 2 - Define routes and their corresponding functions
# Route 1: Home page
@app.route('/')
def home_page():
    return "Welcome to Home Page"

# Route 2: Addition function
@app.route('/add')
def add_fun():
    # Get query parameters a and b
    a = request.args.get('a')
    b = request.args.get('b')
    # Calculate the sum and return as a string
    return str(int(a) + int(b))

# Route 3: Uppercase function
@app.route('/upper')
def make_uppercase():
    # Get the username query parameter
    username = request.args.get('username')
    # Convert the username to uppercase and return
    upper_username = username.upper()
    return upper_username

# Step 3 - Run the app
if __name__ == "__main__":
    app.run()


# In[ ]:




