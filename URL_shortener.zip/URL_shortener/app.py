from flask import Flask, render_template, request, redirect, url_for
import string
import random

app = Flask(__name__)

short_urls = {}

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        long_url = request.form['url']
        short_url = generate_short_url()
        short_urls[short_url] = long_url
        return redirect(url_for('shortened_url', short_url=short_url))
    return render_template('index.html')

@app.route('/<short_url>')
def redirect_url(short_url):
    long_url = short_urls.get(short_url)
    if long_url:
        return redirect(long_url)
    else:
        return render_template('404.html'), 404

@app.route('/shortened/<short_url>')
def shortened_url(short_url):
    return render_template('shortened.html', short_url=request.host_url + short_url)

def generate_short_url():
    letters = string.ascii_lowercase + string.ascii_uppercase + string.digits
    return ''.join(random.choice(letters) for _ in range(8))

if __name__ == '__main__':
    app.run()
